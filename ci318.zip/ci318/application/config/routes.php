<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'email/pesan';
$route['404_override'] = 'user/page404';
$route['translate_uri_dashes'] = FALSE;
